//criando uma conexao do banco de dados com o mongo
const { Mongoose } = require("mongoose");

const mmongoose = requise('mongoose');



//mongoclint é uma forma de conectar com o mongo
mongoose.connect('mongodb://localhostnoderest', {useMongoClient: true});
mongoose.Promise = global.Promise;

module.exports = mongoose;

